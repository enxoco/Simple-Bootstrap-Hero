<?php header("Content-type: text/css; charset: UTF-8"); ?>
body {
    background: <?php echo $context['nav_bg_color']; ?> !important;
}